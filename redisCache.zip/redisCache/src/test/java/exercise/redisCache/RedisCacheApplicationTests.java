package exercise.redisCache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisCacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
